//
//  ShopCell.swift
//  ass3internetshop
//
//  Created by Мас on 07.02.2021.
//

import UIKit

class ShopCell: UITableViewCell {
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var Price: UILabel!
    @IBOutlet weak var addButton: UIButton!
    var item: Item?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func addItem(_ sender: Any) {
        CartTVC.items.append(item!)
    }

    
}
