//
//  CartTVC.swift
//  ass3internetshop
//
//  Created by Мас on 07.02.2021.
//

import UIKit

class CartTVC: UITableViewController {
    static var items: [Item] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
    }
    
    func configureTableView(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ShopCell", bundle: nil), forCellReuseIdentifier: "ShopCell")
        tableView.tableFooterView = UIView()
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return CartTVC.items.count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCell(withIdentifier: "ShopCell", for: indexPath) as! ShopCell
      let item = CartTVC.items[indexPath.row]
      cell.titleLable.text = item.title
      cell.descriptionLabel.text = item.description
      cell.Price.text = "$" + String(format: "%.2f", item.price ?? 0)
      cell.itemImage.image = UIImage(named: item.image!)
      cell.addButton.isHidden = true
      return cell
  }
}
