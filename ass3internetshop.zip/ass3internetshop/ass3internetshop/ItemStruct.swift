//
//  File.swift
//  ass3internetshop
//
//  Created by Мас on 07.02.2021.
//

import Foundation

public struct Item: Codable{
    var title: String?
    var description: String?
    var image: String?
    var price: Double?
    
}
