//
//  ViewController.swift
//  ass3internetshop
//
//  Created by Мас on 04.02.2021.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate {
    
    @IBOutlet weak var listView: UITableView!
    @IBOutlet weak var gridView: UICollectionView!
    @IBOutlet weak var cardButton: UIButton!
    @IBOutlet weak var segmentControlButton: UISegmentedControl!
    var arr = [Item]()
    let cellId = "ShopCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupShopItems()
        configureTableView()
        configureCollectionView()
        
    }
    
    func setupShopItems(){
        arr.append(Item(title: "Тренируй свой мозг", description: "Р. Кавашима", image: "img0", price: 1775))
        arr.append(Item(title: "Алхимик", description: "П. Коэльо", image: "img1", price: 1640))
        arr.append(Item(title: "KazakhMan Batyr", description: "Б.Қазыбек", image: "img2", price: 990))
        arr.append(Item(title: "Финансист", description: "Т. Драйзер", image: "img3", price: 2558))
        arr.append(Item(title: "English is Not Easy", description: "Л. Гутьерес", image: "img4", price: 3370))
        arr.append(Item(title: "Английский разговорник", description: "Лучший помощник в путешествии", image: "img5", price: 2864))
        arr.append(Item(title: "Алхимик", description: "П. Коэльо", image: "img1", price: 1640))
        arr.append(Item(title: "Алхимик", description: "П. Коэльо", image: "img1", price: 1640))
        arr.append(Item(title: "Алхимик", description: "П. Коэльо", image: "img1", price: 1640))
        arr.append(Item(title: "Алхимик", description: "П. Коэльо", image: "img1", price: 1640))
    }
    
    func configureTableView(){
        listView.delegate = self
        listView.dataSource = self
        listView.register(UINib(nibName: "ShopCell", bundle: nil), forCellReuseIdentifier: "ShopCell")
        listView.tableFooterView = UIView()
        
    }
    
    func configureCollectionView(){
        gridView.delegate = self
        gridView.dataSource = self
        gridView.register(UINib(nibName: "ShopCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ShopCollectionViewCell")
        
    }

    @IBAction func changeLayout(_ sender: UISegmentedControl) {
        if gridView.isHidden{
            listView.isHidden=true
            gridView.isHidden=false
        }
        else {
            listView.isHidden=false
            gridView.isHidden=true
        }
    }
    @IBAction func moveCart(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "CartTVC") as! CartTVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
}


extension ViewController: UITableViewDelegate, UITableViewDataSource{

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! ShopCell
        let item = arr[indexPath.row]
        cell.titleLable.text = item.title
        cell.descriptionLabel.text = item.description
        cell.Price.text = "kzt" + String(format: "%.2f", item.price ?? 0)
        cell.itemImage.image = UIImage(named: item.image!)
        cell.item = item
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = arr[indexPath.row]
        let vc = storyboard?.instantiateViewController(identifier: "ItemVC") as! ItemVC
        vc.item = item
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension ViewController: UICollectionViewDataSource{
   
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = gridView.dequeueReusableCell(withReuseIdentifier: "ShopCollectionViewCell", for: indexPath) as! ShopCollectionViewCell
        let item = arr[indexPath.row]
        cell.titleLabel.text = item.title
        cell.descriptionLabel.text = item.description
        cell.priceLable.text = "kzt" + String(format: "%.2f", item.price ?? 0)
        cell.itemImage.image = UIImage(named: item.image!)
        cell.item = item
        
        if (cell.addButton.isSelected) {
            CartTVC.items.append(item)
        }

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = arr[indexPath.row]
        let vc = storyboard?.instantiateViewController(identifier: "ItemVC") as! ItemVC
        vc.item = item
        navigationController?.pushViewController(vc, animated: true)    }
}



