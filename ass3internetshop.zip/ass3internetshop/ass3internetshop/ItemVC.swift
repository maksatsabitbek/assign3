//
//  ItemVC.swift
//  ass3internetshop
//
//  Created by Мас on 07.02.2021.
//

import UIKit

class ItemVC: UIViewController {
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var addButton: UIButton!
    var item: Item?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.titleLabel.text = item?.title
        self.descriptionLabel.text = item?.description
        self.priceLabel.text = "kzt" + String(format: "%.2f", item?.price ?? 0)
        self.itemImage.image = UIImage(named: (item?.image!)!)
        
    }
    
    
    @IBAction func addItem(_ sender: Any) {
        CartTVC.items.append(item!)
    }
    
   

}
